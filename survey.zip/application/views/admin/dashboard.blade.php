@section('title')
Dashboard - Admin
@endsection

@section('content')
<div class="page" id="dashboard-page">
	<div class="page-header clearfix">
		<div class="pull-left title">
			<h2>Dashboard</h2>
		</div>
	</div>
</div>
@endsection