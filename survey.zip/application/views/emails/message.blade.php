<!doctype html>
<html lang="en-gb">
	<head>
		<meta charset="UTF-8">
		<title></title>

		<style type="text/css">
		</style>
	</head>

	<body>
		<div id="background">
			<p>From: {{ $name }}</p>
			<p>{{ $message }}</p>
		</div>
	</body>
</html>