<?php
	
	return array(

		'url' => "",

		'key' => md5("secret"),
	);