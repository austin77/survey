<?php
	
	return array(

		'url' => "http://localhost/survey/public",

		'key' => md5("food"),
	);